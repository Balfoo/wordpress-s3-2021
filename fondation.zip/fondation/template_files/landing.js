/**
 * /!\ We use CSS3 sticky position, we just add sticky class to have specifics alternatives styles 
 * @param {sectionNavElementClass}
 */
(function ( { sectionNavElementClass } = props ) {
    sectionNavElement = document.querySelector('.'+sectionNavElementClass);
    sectionNavStickyClass = sectionNavElementClass+'--sticky';
    var stickyFunc = function(e) {
        if( sectionNavElement.offsetTop <= window.pageYOffset ) {
            sectionNavElement.classList.add( sectionNavStickyClass );
        }
        else {
            sectionNavElement.classList.remove( sectionNavStickyClass );
        }
    } 
    window.addEventListener('scroll', function(e) {
        stickyFunc(e);
    });
    stickyFunc();
}( { 'sectionNavElementClass' : 'section-nav-landing' } ));

jQuery('.nav-landing-list-element-link').click( function(e){
    e.preventDefault();
    jQuery(this).blur();
    var hash = e.target.hash;
    var target = jQuery(hash);
    var targetPos = target.offset().top - 120;
    jQuery( 'body, html' ).animate( { scrollTop: targetPos }, 500, 'swing', function() {
        if(history.pushState) {
            history.pushState(null, null, hash);
        }
    } );
} );

jQuery.fn.isInViewport = function() {
    var elementTop = jQuery(this).offset().top;
    var elementBottom = elementTop + jQuery(this).outerHeight();
    var viewportTop = jQuery(window).scrollTop();
    var viewportBottom = viewportTop + jQuery(window).height();
    return elementBottom > viewportTop && elementTop < viewportBottom;
};

var sections = jQuery('.section-line');
jQuery(document).on("scroll", function(){
    sections.each( function(index){
        var navEl = jQuery('.link-'+(index+1));
        var _this = jQuery(this);
        var navEl = jQuery( '.' + _this.attr('attr-nav') );
        var navActive = jQuery( '.nav-landing-list-element-link.active' );
        if( _this.isInViewport() ) {
            navActive.removeClass('active');
            navEl.addClass('active');
        }
    });
});